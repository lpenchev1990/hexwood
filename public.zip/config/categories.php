<?php
return [

    'lamps' => [
        'id' => 1,
        'name' => 'Лампи',
        'image' => 'assets/img/category/lamp.jpg',
    ],
    'shelfs' => [
        'id' => 2,
        'name' => 'Етажерки',
        'image' => 'assets/img/category/shelfs.jpg',
    ],

    'small-furniture' => [
        'id' => 3,
        'name' => 'Малки мебели',
        'image' => 'assets/img/category/small.jpg',
    ],

    'pets-furniture' => [
        'id' => 4,
        'name' => 'Домашни любимци',
        'image' => 'assets/img/category/pets.jpg',
    ],
    'coffee-tables' => [
        'id' => 5,
        'name' => 'Холни маси',
        'image' => 'assets/img/category/coffee.jpg',
    ],

    'others' => [
        'id' => 6,
        'name' => 'Други',
        'image' => 'assets/img/category/others.jpg',
    ],

    'your-idea' => [
        'id' => 7,
        'name' => 'Вашата идея',
        'image' => 'assets/img/category/idea.jpg',
    ],
];
