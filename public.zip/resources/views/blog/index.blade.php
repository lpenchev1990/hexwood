@include('layouts.header')
@include('components.hader')


<!--====== BREADCRUMB PART START ======-->
<section class="breadcrumb-area" style="background-image: url({{asset('assets/img/images/aboutus.jpg')}}); margin-top: 165px">
    <div class="container">
        <div class="breadcrumb-text">
            <h2 class="page-title">Блог</h2>
            <ul class="breadcrumb-nav">
                <li><a href="{{ route('home') }}">Начало</a></li>
                <li class="active">Блог</li>
            </ul>
        </div>
    </div>
</section>

<section class="blog-section pt-120 pb-120">
    <div class="container">
        <div class="row justify-content-center column-reverse">
            <div class="col-lg-8 col-md-10">
                <div class="blog-loop">
                    <div class="post-box mb-40">
                        <div class="post-media">
                            <img src="assets/img/blog/01.jpg" alt="Image">
                        </div>
                        <div class="post-desc">
                            <a href="#" class="cat">Businese</a>
                            <h2>
                                <a href="blog-details.html">How to Shop For Jewelry When You Have a Metal Allergy.</a>
                            </h2>
                            <ul class="post-meta">
                                <li><a href="#"><i class="far fa-eye"></i>232 Views</a>
                                </li>
                                <li><a href="#"><i class="far fa-comments"></i>35 Comments</a>
                                </li>
                                <li><a href="#"><i class="far fa-calendar-alt"></i>24th March 2025</a>
                                </li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.</p>
                            <div class="post-footer">
                                <div class="author">
                                    <a href="#">
                                        <img src="assets/img/author-small.png" alt="Image">by Hetmayar</a>
                                </div>
                                <div class="read-more"> <a href="blog-details.html"><i class="far fa-arrow-right"></i>Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="post-box with-video mb-40">
                        <div class="post-media">
                            <img src="assets/img/blog/02.jpg" alt="Image"> <a href="#" class="play-icon"><i class="fas fa-play"></i></a>
                        </div>
                        <div class="post-desc">
                            <a href="#" class="cat">Businese</a>
                            <h2>
                                <a href="blog-details.html">Jewelry Time Periods: A Timeline of Jewelry Styles and Trends.</a>
                            </h2>
                            <ul class="post-meta">
                                <li><a href="#"><i class="far fa-eye"></i>232 Views</a>
                                </li>
                                <li><a href="#"><i class="far fa-comments"></i>35 Comments</a>
                                </li>
                                <li><a href="#"><i class="far fa-calendar-alt"></i>24th March 2025</a>
                                </li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.</p>
                            <div class="post-footer">
                                <div class="author">
                                    <a href="#">
                                        <img src="assets/img/author-small.png" alt="Image">by Hetmayar</a>
                                </div>
                                <div class="read-more"> <a href="blog-details.html"><i class="far fa-arrow-right"></i>Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pagination-wrap">
                    <ul>
                        <li><a href="#"><i class="far fa-angle-double-left"></i></a>
                        </li>
                        <li class="active"><a href="#">1</a>
                        </li>
                        <li><a href="#">2</a>
                        </li>
                        <li><a href="#">3</a>
                        </li>
                        <li><a href="#">...</a>
                        </li>
                        <li><a href="#">10</a>
                        </li>
                        <li><a href="#"><i class="far fa-angle-double-right"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


@include("layouts.footer")
