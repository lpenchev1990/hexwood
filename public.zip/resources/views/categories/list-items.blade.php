<div class="col-lg-12 col-md-12">
    <div class="shop-products-wrapper">
        <div class="shop-product-top">
            <p>Showing 1 To 9 Of 60 results</p>
            <div class="sorting-box">
                <select name="guests" id="guests">
                    <option value="" disabled selected>Default Sorting</option>
                    <option value="1">Sort By Popularity</option>
                    <option value="2">Sort By Latest</option>
                    <option value="4">Sort By Rating</option>
                    <option value="8">Sort By Price:Low to High</option>
                    <option value="8">Sort By Price:High to Low</option>
                </select>
            </div>
        </div>
        <div class="product-wrapper restaurant-tab-area">
            <div class="row">
                @for($i = 1 ; $i <= 12; $i++)
                    <div class="col-lg-4 col-md-12">
                        <div class="food-box shop-box">
                            <div class="thumb">
                                <img src="{{asset('assets/img/shop/01.jpg')}}" alt="images">
                                <div class="badges">
                                    <span class="price">Sale</span>
                                    <span class="price discounted">-15%</span>
                                </div>
                                <div class="button-group">
                                    <a href="#"><i class="far fa-heart"></i></a>
                                    <a href="#"><i class="far fa-sync-alt"></i></a>
                                    <a href="#" data-toggle="modal" data-target="#quickViewModal"><i class="far fa-eye"></i></a>
                                </div>
                            </div>
                            <div class="desc">
                                <h4>
                                    <a href="shop-detail.html">Ankle Bracelet</a>
                                </h4>
                                <span class="price">$390 <span>$480</span></span>
                                <a href="shop-detail.html" class="link"><i class="fal fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>

                @endfor
            </div>
        </div>
    </div>
    <div class="pagination-wrap">
        <ul>
            <li><a href="#"><i class="far fa-angle-double-left"></i></a></li>
            <li class="active"><a href="#">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">...</a></li>
            <li><a href="#">10</a></li>
            <li><a href="#"><i class="far fa-angle-double-right"></i></a></li>
        </ul>
    </div>
</div>
