<?php

namespace App\Http\Controllers\Front;

use App\Models\Home;
use App\Models\Page;
use App\Http\Controllers\Controller;
class PageController extends Controller
{
    public function home()
    {
        // $data = (new Home())->getHomeData();
        return $this->viewExt('pages.home');
    }

    public function about()
    {
        $page = (new Page())->getPageBySlug('about-us');
        return view('pages.page', compact('page'));
    }

    public function contacts()
    {
        $page = (new Page())->getPageBySlug('contacts');
        return view('pages.page', compact('page'));
    }
}
