<?php

namespace App\Http\Controllers\Front;

use App\Models\Blog;
use App\Http\Controllers\Controller;
class BlogController extends Controller
{
    public function index()
    {
//        $posts = (new Blog())->getPosts();
        return $this->viewExt('blog.index');
    }

    public function detail(string $slug)
    {
            return $this->viewExt('blog.detail');
    }
}
