<?php

namespace App\Http\Controllers\Front;

use App\Models\Category;
use App\Models\Product;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = (new Category())->getCategories();
        return view('categories.index', compact('categories'));
    }

    public function detail(string $slug)
    {
        $showArticles = 1;
        if ($slug == 'your-idea') $showArticles = 0;
        return $this->viewExt('categories.detail', ['category' => config('categories.'.$slug), 'showArticles' => $showArticles]);
    }

    public function productDetail(string $slug)
    {
        $product = (new Product())->getProductBySlug($slug);
        return view('products.detail', compact('product'));
    }
}
