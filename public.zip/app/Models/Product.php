<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;

class Product
{
    protected string $table = 'products';

    public function getProductBySlug(string $slug)
    {
        return DB::table($this->table)
            ->where('slug', $slug)
            ->first();
    }
}
