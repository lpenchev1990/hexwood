<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('components.hader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<!--====== BREADCRUMB PART START ======-->
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset($category['image'])); ?>); margin-top: 165px">
    <div class="container">
        <div class="breadcrumb-text">
            <h2 class="page-title"><?php echo e($category['name']); ?></h2>
            <ul class="breadcrumb-nav">
                <li><a href="<?php echo e(route('home')); ?>">Начало</a></li>
                <li class="active"><?php echo e($category['name']); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--====== BREADCRUMB PART END ======-->
<!--====== SHOP SECTION START ======-->
<section class="Shop-section pt-120 pb-120">
    <div class="container">
        <div class="row justify-content-center">
            <!-- Shop Sidebar -->
            <?php if($showArticles == 1): ?>
                <?php echo $__env->make('categories.list-items', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make("categories.your-idea", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php echo $__env->make("layouts.footer", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hexwood\resources\views/categories/detail.blade.php ENDPATH**/ ?>